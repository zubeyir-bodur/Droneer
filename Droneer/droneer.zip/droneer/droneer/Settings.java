/*
 *@author agil Aliyev
 * @version 6.5.2019
 */
   
package droneer;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Settings extends JPanel{
   JSpinner spinForResolution;
   String[] res;
   int screenHeight, screenWidth;
   JPanel panelForSettingsLabel, panelForResolution;
   JLabel settingsLabel, resolution;
   Color myColor;
   public Settings(){
      //getting screen size
      screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
      screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
      //imageicon

      //panels
      panelForSettingsLabel = new JPanel();
      panelForResolution = new JPanel();
      //label settings
      myColor= new Color(0,0,0, 100);
      settingsLabel = new JLabel("Settings");
      settingsLabel.setForeground(Color.WHITE);
      settingsLabel.setBackground(myColor);
      settingsLabel.setOpaque(true);
      //label resolution
      resolution = new JLabel("Resolution:");
      resolution.setForeground(Color.WHITE);
      resolution.setBackground(myColor);
      resolution.setOpaque(true);
      //background for  panels etc
      setBackground(new Color(0,0,0, 0));
      panelForResolution.setBackground(new Color(0,0,0, 0));
      panelForSettingsLabel.setBackground(new Color(0,0,0, 0));
      setBackground(Color.blue);
      
      //layouts
      panelForSettingsLabel.setLayout(new FlowLayout());
      setLayout(new GridLayout(7,1));
      //font sizes
      settingsLabel.setFont(new Font("Serif", Font.PLAIN, screenWidth/25));
      resolution.setFont(new Font("Serif", Font.PLAIN, screenWidth/50));
      //resolution string and other stuff
      String[] tmp = {"1280�720","1366�768","1600�900","1920�1080", "2560�1440", "3840�2160"};
      res = tmp;
      spinForResolution = new JSpinner(new SpinnerListModel(res));
      spinForResolution.setPreferredSize(new Dimension(screenWidth/10, screenHeight/25));
      spinForResolution.setBackground(Color.red);
      spinForResolution.setFont(new Font("Serif", Font.PLAIN, screenWidth/50));
      
      //adding 
      panelForSettingsLabel.add(settingsLabel);
      panelForResolution.add(resolution);
      panelForResolution.add(spinForResolution);
      add(panelForSettingsLabel);
      add(panelForResolution);
   }
}